<html>
<body>

<center>
<?php 
  echo "<h1>Hello World, PHP!</h1>"; 
?>
</center>

</body>
</html>